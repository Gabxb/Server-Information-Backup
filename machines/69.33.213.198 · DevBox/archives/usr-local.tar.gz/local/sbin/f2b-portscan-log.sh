#!/bin/sh
# Install nftables INPUT logging for unsolicited TCP SYN / UDP probes.
# Uses a dedicated table so it does not flush fail2ban's f2b-table.
set -e

nft delete table inet f2b-pscan 2>/dev/null || true

nft -f - <<'EOF'
table inet f2b-pscan {
	set allow_tcp {
		type inet_service
		elements = { 22, 443, 8080 }
	}
	set allow_udp {
		type inet_service
		elements = { 68, 5355 }
	}
	chain input {
		type filter hook input priority 10; policy accept;
		iif "lo" accept
		ct state established,related accept
		tcp dport @allow_tcp accept
		udp dport @allow_udp accept
		ct state new tcp flags syn / fin,syn,rst,ack limit rate 20/second burst 40 packets log prefix "f2b-pscan: "
		ct state new meta l4proto udp limit rate 10/second burst 20 packets log prefix "f2b-pscan: "
	}
}
EOF
